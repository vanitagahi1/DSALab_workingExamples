 import java.util.ArrayList;
import java.util.Collections;

    class BinaryTreeToBST {
        // Definition of the TreeNode
        static class TreeNode {
            int val;
            TreeNode left, right;

            TreeNode(int val) {
                this.val = val;
            }
        }

        // Function to collect tree nodes in in-order traversal
        private static void inOrderTraversal(TreeNode root, ArrayList<Integer> nodes) {
            if (root != null) {
                inOrderTraversal(root.left, nodes);
                nodes.add(root.val);
                inOrderTraversal(root.right, nodes);
            }
        }

        // Function to convert the binary tree to BST
        private static void convertToBST(TreeNode root, ArrayList<Integer> nodes) {
            if (root != null) {
                convertToBST(root.left, nodes);
                root.val = nodes.remove(0); // Replace the value with the sorted element
                convertToBST(root.right, nodes);
            }
        }

        // Function to convert a binary tree to BST
        public static TreeNode binaryTreeToBST(TreeNode root) {
            if (root == null) return null;

            ArrayList<Integer> nodes = new ArrayList<>();
            // Step 1: Perform in-order traversal to collect all elements
            inOrderTraversal(root, nodes);

            // Step 2: Sort the collected elements
            Collections.sort(nodes);

            // Step 3: Perform in-order traversal again and replace values
            convertToBST(root, nodes);

            return root;
        }

        // Function for in-order traversal to print the tree
        public static void inOrder(TreeNode root) {
            if (root != null) {
                inOrder(root.left);
                System.out.print(root.val + " ");
                inOrder(root.right);
            }
        }

        public static void main(String[] args) {
            // Create a binary tree
            TreeNode root = new TreeNode(20);
            root.left = new TreeNode(5);
            root.right = new TreeNode(17);
            root.left.left = new TreeNode(6);
            root.left.right = new TreeNode(25);

            System.out.println("In-order traversal of the original binary tree:");
            inOrder(root);
            System.out.println();

            // Convert binary tree to BST
            binaryTreeToBST(root);

            System.out.println("In-order traversal of the converted BST:");
            inOrder(root);
            System.out.println();
        }
    }


