 public class SortedArrayToBST {
        // Definition of the TreeNode
        static class TreeNode {
            int val;
            TreeNode left, right;

            TreeNode(int val) {
                this.val = val;
            }
        }

        // Function to convert a sorted array to a BST
        public static TreeNode sortedArrayToBST(int[] nums) {
            return buildBST(nums, 0, nums.length - 1);
        }

        // Helper function to recursively build the BST
        private static TreeNode buildBST(int[] nums, int start, int end) {
            if (start > end) return null;

            // Choose the middle element as the root
            int mid = start + (end - start) / 2;
            TreeNode node = new TreeNode(nums[mid]);

            // Recursively build the left and right subtrees
            node.left = buildBST(nums, start, mid - 1);
            node.right = buildBST(nums, mid + 1, end);

            return node;
        }

        // In-order traversal to print the BST
        public static void inOrder(TreeNode root) {
            if (root != null) {
                inOrder(root.left);
                System.out.print(root.val + " ");
                inOrder(root.right);
            }
        }

        public static void main(String[] args) {
            int[] sortedArray = {0 , 5 , 9 , 2 ,6};

            // Convert the sorted array to BST
            TreeNode root = sortedArrayToBST(sortedArray);

            System.out.println("In-order traversal of the BST:");
            inOrder(root); // Output should match the sorted array
        }
    }


