public class ExpressionTree {
        // Node class for the tree
        static class Node {
            String value;
            Node left, right;

            Node(String value) {
                this.value = value;
            }
        }

        // Function to construct the expression tree
        public static Node constructExpressionTree() {
            // Constructing the tree for ((5+2)*(2-1))/(2+9)

            // Leaf nodes
            Node n1 = new Node("5");
            Node n2 = new Node("2");
            Node n3 = new Node("2");
            Node n4 = new Node("1");
            Node n5 = new Node("2");
            Node n6 = new Node("9");

            // Internal nodes
            Node plus1 = new Node("+");
            plus1.left = n1; // 5
            plus1.right = n2; // 2

            Node minus = new Node("-");
            minus.left = n3; // 2
            minus.right = n4; // 1

            Node multiply = new Node("*");
            multiply.left = plus1; // (5 + 2)
            multiply.right = minus; // (2 - 1)

            Node plus2 = new Node("+");
            plus2.left = n5; // 2
            plus2.right = n6; // 9

            Node divide = new Node("/");
            divide.left = multiply; // (5 + 2) * (2 - 1)
            divide.right = plus2; // (2 + 9)

            return divide; // Root node
        }

        // In-order traversal of the tree
        public static void inOrder(Node root) {
            if (root != null) {
                inOrder(root.left);
                System.out.print(root.value + " ");
                inOrder(root.right);
            }
        }

        // Pre-order traversal of the tree
        public static void preOrder(Node root) {
            if (root != null) {
                System.out.print(root.value + " ");
                preOrder(root.left);
                preOrder(root.right);
            }
        }

        // Post-order traversal of the tree
        public static void postOrder(Node root) {
            if (root != null) {
                postOrder(root.left);
                postOrder(root.right);
                System.out.print(root.value + " ");
            }
        }

        public static void main(String[] args) {
            // Construct the expression tree
            Node root = constructExpressionTree();

            System.out.println("In-order traversal:");
            inOrder(root);
            System.out.println();

            System.out.println("Pre-order traversal:");
            preOrder(root);
            System.out.println();

            System.out.println("Post-order traversal:");
            postOrder(root);
            System.out.println();
        }
    }


