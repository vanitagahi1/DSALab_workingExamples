 import java.util.Scanner;

    public class TextEditor2 {

            static class Node {
                char data;
                Node next;
                Node prev;

                public Node(char data) {
                    this.data = data;
                }
            }

            static class TextEditor {
                private Node head;
                private Node tail;

                // Insert a character at the end
                public void insert(char data) {
                    Node newNode = new Node(data);
                    if (head == null) {
                        head = tail = newNode;
                    } else {
                        tail.next = newNode;
                        newNode.prev = tail;
                        tail = newNode;
                    }
                }


                public void deleteLast() {
                    if (tail == null) {
                        System.out.println("No characters to delete!");
                        return;
                    }
                    if (head == tail) {
                        head = tail = null;
                    } else {
                        tail = tail.prev;
                        tail.next = null;
                    }
                }


                public void modify(int position, char newData) {
                    if (position < 0) {
                        System.out.println("Invalid position!");
                        return;
                    }

                    Node current = head;
                    for (int i = 0; i < position; i++) {
                        if (current == null) {
                            System.out.println("Position out of bounds!");
                            return;
                        }
                        current = current.next;
                    }

                    if (current != null) {
                        current.data = newData;
                    }
                }


                public void display() {
                    if (head == null) {
                        System.out.println("No text to display!");
                        return;
                    }

                    Node current = head;
                    while (current != null) {
                        System.out.print(current.data);
                        current = current.next;
                    }
                    System.out.println();
                }
            }

            public static void main(String[] args) {
                TextEditor editor = new TextEditor();
                Scanner scanner = new Scanner(System.in);

                while (true) {
                    System.out.println("\nText Editor");
                    System.out.println("1. Insert character");
                    System.out.println("2. Delete last character");
                    System.out.println("3. Modify character");
                    System.out.println("4. Display text");
                    System.out.println("5. Exit");
                    System.out.print("Choose an option: ");
                    int choice = scanner.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.print("Enter character to insert: ");
                            char data = scanner.next().charAt(0);
                            editor.insert(data);
                            break;
                        case 2:
                            editor.deleteLast();
                            break;
                        case 3:
                            System.out.print("Enter position to modify: ");
                            int position = scanner.nextInt();
                            System.out.print("Enter new character: ");
                            char newData = scanner.next().charAt(0);
                            editor.modify(position, newData);
                            break;
                        case 4:
                            System.out.print("Current text: ");
                            editor.display();
                            break;
                        case 5:
                            System.out.println("Exiting editor...");
                            scanner.close();
                            return;
                        default:
                            System.out.println("Invalid option! Try again.");
                    }
                }
            }
        }

