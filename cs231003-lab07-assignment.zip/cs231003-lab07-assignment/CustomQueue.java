 public class CustomQueue {


        static class Node {
            int data;
            Node next;

            public Node(int data) {
                this.data = data;
                this.next = null;
            }
        }


        static class Queue {
            private Node front, rear;


            public Queue() {
                front = rear = null;
            }


            public void enqueue(int data) {
                Node newNode = new Node(data);
                if (rear == null) {
                    front = rear = newNode;
                } else {
                    rear.next = newNode;
                    rear = newNode;
                }
            }


            public int dequeue() {
                if (front == null) {
                    System.out.println("Queue is empty!");
                    return -1; // Indicates empty queue
                }
                int data = front.data;
                front = front.next;
                if (front == null) {
                    rear = null;
                }
                return data;
            }


            public void reverseFirstKElements(int k) {
                if (k <= 0 || front == null) {
                    System.out.println("Invalid K or empty queue!");
                    return;
                }


                Stack stack = new Stack();
                int count = 0;


                Node temp = front;
                while (count < k && temp != null) {
                    stack.push(temp.data);
                    temp = temp.next;
                    count++;
                }


                while (!stack.isEmpty()) {
                    enqueue(stack.pop());
                }


                while (temp != null) {
                    enqueue(temp.data);
                    temp = temp.next;
                }
            }


            public int getMinimum() {
                if (front == null) {
                    System.out.println("Queue is empty!");
                    return -1;
                }

                int min = front.data;
                Node temp = front.next;
                while (temp != null) {
                    if (temp.data < min) {
                        min = temp.data;
                    }
                    temp = temp.next;
                }
                return min;
            }


            public void display() {
                if (front == null) {
                    System.out.println("Queue is empty!");
                    return;
                }

                Node temp = front;
                while (temp != null) {
                    System.out.print(temp.data + " ");
                    temp = temp.next;
                }
                System.out.println();
            }

            static class Stack {
                private Node top;

                // Constructor
                public Stack() {
                    top = null;
                }


                public void push(int data) {
                    Node newNode = new Node(data);
                    newNode.next = top;
                    top = newNode;
                }

                // Pop an element from the stack
                public int pop() {
                    if (top == null) {
                        System.out.println("Stack is empty!");
                        return -1; // Indicates empty stack
                    }
                    int data = top.data;
                    top = top.next;
                    return data;
                }


                public boolean isEmpty() {
                    return top == null;
                }
            }
        }


        public static void main(String[] args) {
            Queue queue = new Queue();


            queue.enqueue(10);
            queue.enqueue(20);
            queue.enqueue(30);
            queue.enqueue(40);
            queue.enqueue(50);

            System.out.print("Original Queue: ");
            queue.display();


            queue.reverseFirstKElements(3);
            System.out.print("Queue after reversing first 3 elements: ");
            queue.display();


            System.out.println("Minimum element in the queue: " + queue.getMinimum());

         
            System.out.println("Dequeue element: " + queue.dequeue());
            System.out.print("Queue after dequeue: ");
            queue.display();
        }
    }


