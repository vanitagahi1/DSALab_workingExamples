 public class CustomStack {

        static class Node {
            int data;
            Node next;

            public Node(int data) {
                this.data = data;
            }
        }


        static class Stack {
            private Node top;


            public void push(int data) {
                Node newNode = new Node(data);
                newNode.next = top;
                top = newNode;
            }


            public int pop() {
                if (isEmpty()) {
                    throw new RuntimeException("Stack is empty!");
                }
                int data = top.data;
                top = top.next;
                return data;
            }


            public int peek() {
                if (isEmpty()) {
                    System.out.println("Stack is empty!");
                }
                return top.data;
            }

            public boolean isEmpty() {
                return top == null;
            }
        }


        public static String reverseString(String input) {
            Stack stack = new Stack();
            for (char c : input.toCharArray()) {
                stack.push(c);
            }

            StringBuilder reversed = new StringBuilder();
            while (!stack.isEmpty()) {
                reversed.append((char) stack.pop());
            }
            return reversed.toString();
        }

        // 2. Reverse a number using the custom stack
        public static int reverseNumber(int number) {
            Stack stack = new Stack();
            while (number > 0) {
                stack.push(number % 10);
                number /= 10;
            }

            int reversed = 0;
            int place = 1;
            while (!stack.isEmpty()) {
                reversed += stack.pop() * place;
                place *= 10;
            }
            return reversed;
        }


        public static int searchElement(Stack stack, int element) {
            Stack tempStack = new Stack();
            int index = -1;
            int position = 0;


            while (!stack.isEmpty()) {
                int current = stack.pop();
                tempStack.push(current);
                if (current == element) {
                    index = position;
                }
                position++;
            }


            while (!tempStack.isEmpty()) {
                stack.push(tempStack.pop());
            }

            return index;
        }


        public static void main(String[] args) {

            String input = "world";
            System.out.println("Reversed string: " + reverseString(input));


            int number = 67890;
            System.out.println("Reversed number: " + reverseNumber(number));


            Stack stack = new Stack();
            stack.push(10);
            stack.push(20);
            stack.push(30);
            stack.push(40);
            stack.push(50);


            System.out.println("Element 30 found at index: " + searchElement(stack, 30)); // Expected: 2
            System.out.println("Element 60 found at index: " + searchElement(stack, 60)); // Expected: -1


            System.out.println("Top of the stack (peek): " + stack.peek()); // Expected: 50
        }
    }


