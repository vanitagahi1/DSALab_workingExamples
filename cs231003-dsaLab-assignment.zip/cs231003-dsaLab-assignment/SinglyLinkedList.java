public class SinglyLinkedList {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head;

    //  Find the length of a given SLL
    public int getLength() {
        int length = 0;
        Node current = head;
        while (current != null) {
            length++;
            current = current.next;
        }
        return length;
    }

    //  Print the middle node of a given SLL
    public void printMiddle() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node n1 = head, n2 = head;
        while (n2 != null && n2.next != null) {
            n1 = n1.next;
            n2 = n2.next.next;
        }
        System.out.println("Middle Node: " + n1.data);
    }

    //  Reverse a given SLL
    public SinglyLinkedList reverseCopy() {
        SinglyLinkedList reversedList = new SinglyLinkedList();
        Node current = head;
        while (current != null) {
            Node newNode = new Node(current.data);
            newNode.next = reversedList.head;
            reversedList.head = newNode;
            current = current.next;
        }
        return reversedList;
    }

    // Remove duplicates from a sorted SLL
    public void removeDuplicates() {
        if (head == null) return;
        Node current = head;
        while (current.next != null) {
            if (current.data == current.next.data) {
                current.next = current.next.next;
            } else {
                current = current.next;
            }
        }
    }

    // Merge two sorted SLL
    public static SinglyLinkedList mergeSortedLists(SinglyLinkedList list1, SinglyLinkedList list2) {
        SinglyLinkedList mergedList = new SinglyLinkedList();
        Node duplicate = new Node(0);
        Node current = duplicate;

        Node l1 = list1.head;
        Node l2 = list2.head;

        while (l1 != null && l2 != null) {
            if (l1.data <= l2.data) {
                current.next = new Node(l1.data);
                l1 = l1.next;
            } else {
                current.next = new Node(l2.data);
                l2 = l2.next;
            }
            current = current.next;
        }

        while (l1 != null) {
            current.next = new Node(l1.data);
            l1 = l1.next;
            current = current.next;
        }

        while (l2 != null) {
            current.next = new Node(l2.data);
            l2 = l2.next;
            current = current.next;
        }

        mergedList.head = duplicate.next;
        return mergedList;
    }

    // Function 6: Delete complete SLL
    public void deleteList() {
        head = null;
        System.out.println("List deleted successfully.");
        
    }

    // Utility Functions
    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Main Function for Testing
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.add(1);
        list.add(2);
        list.add(2);
        list.add(3);
        list.add(4);

        System.out.println("Original List:");
        list.printList();

        // Task 1
        System.out.println("Length of the list: " + list.getLength());

        // Task 2
        list.printMiddle();

        // Task 3
        SinglyLinkedList reversedList = list.reverseCopy();
        System.out.println("Reversed List:");
        reversedList.printList();

        // Task 4
        list.removeDuplicates();
        System.out.println("List after removing duplicates:");
        list.printList();

        // Task 5
        SinglyLinkedList list2 = new SinglyLinkedList();
        list2.add(1);
        list2.add(3);
        list2.add(5);
        System.out.println("Second Sorted List:");
        list2.printList();
        SinglyLinkedList mergedList = mergeSortedLists(list, list2);
        System.out.println("Merged Sorted List:");
        mergedList.printList();

        // Task 6
        list.deleteList();
        System.out.println("After deletion:");
        list.printList();
    }
}


